<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('crusades', function (Blueprint $table) {
            $table->timestamp('published_at')->nullable()->after('ends_at');
            $table->index(['published_at', 'ends_at', 'starts_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('crusades', function (Blueprint $table) {
            $table->dropIndex(['published_at', 'ends_at', 'starts_at']);
            $table->dropColumn('published_at');
        });
    }
};
