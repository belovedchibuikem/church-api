<?php

namespace App\Admin;

enum AdminDashboardModule: string
{
    case Global = 'global';
    case Geography = 'geography';
    case HomeChurches = 'home-churches';
    case Church = 'church';
    case Kca = 'kca';
    case Mission = 'mission';
    case Press = 'press';
    case Finance = 'finance';
    case Communications = 'communications';
    case Reports = 'reports';
    case Security = 'security';

    public function permission(): string
    {
        return match ($this) {
            self::Global => 'admin.dashboard.view',
            self::Geography => 'organization.view',
            self::HomeChurches => 'home_church.dashboard.view',
            self::Church => 'church.dashboard.view',
            self::Kca => 'kca.dashboard.view',
            self::Mission => 'mission.dashboard.view',
            self::Press => 'press.dashboard.view',
            self::Finance => 'finance.dashboard.view',
            self::Communications => 'communications.dashboard.view',
            self::Reports => 'reports.global.view',
            self::Security => 'security.dashboard.view',
        };
    }

    public static function fromRoute(string $module): self
    {
        return self::tryFrom($module) ?? throw new \InvalidArgumentException('Unknown dashboard module.');
    }
}
