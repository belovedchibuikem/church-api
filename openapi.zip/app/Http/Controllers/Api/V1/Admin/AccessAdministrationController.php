<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Api\V1\Admin\Concerns\ExecutesDomainMutations;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\V1\Admin\AssignRoleToUserRequest;
use App\Http\Requests\Api\V1\Admin\AssignScopeToRoleAssignmentRequest;
use App\Http\Requests\Api\V1\Admin\GrantPermissionToRoleRequest;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleAssignment;
use App\Models\RolePermission;
use App\Models\ScopeAssignment;
use App\Models\User;
use App\Queries\User\ListUserCapabilitiesQuery;
use App\Services\Admin\ProtectedAdminContext;
use App\Support\Api\ApiResponse;
use App\Support\Authorization\AssignRoleToUserAction;
use App\Support\Authorization\AssignScopeToRoleAssignmentAction;
use App\Support\Authorization\AuthorizationBundleCatalog;
use App\Support\Authorization\GrantPermissionToRoleAction;
use App\Support\Authorization\ReconcileChurchOperatorScopesAction;
use App\Support\Authorization\RevokeRoleFromUserAction;
use App\Support\Authorization\ScopeReference;
use Carbon\CarbonImmutable;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use InvalidArgumentException;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class AccessAdministrationController extends Controller
{
    use ExecutesDomainMutations;

    public function assignRole(
        AssignRoleToUserRequest $request,
        string $user,
        AssignRoleToUserAction $action,
        AssignScopeToRoleAssignmentAction $assignScope,
        ReconcileChurchOperatorScopesAction $reconcileChurchScopes,
        ProtectedAdminContext $context,
    ): JsonResponse {
        $context->ensureGlobal($request);
        $target = User::query()->where('public_id', $user)->firstOrFail();
        $role = Role::query()->where('public_id', $request->validated('role_id'))->firstOrFail();
        if ($role->code === AuthorizationBundleCatalog::SUPER_ADMINISTRATOR_ROLE) {
            $this->assertActorHoldsSuperAdministrator($context->actor($request));
        }
        $assignment = $this->execute(function () use ($request, $target, $role, $action, $assignScope, $reconcileChurchScopes, $context): RoleAssignment {
            $created = $action->handle(
                $target,
                $role,
                $context->actor($request),
                $request->validated('expires_at') === null ? null : CarbonImmutable::parse((string) $request->validated('expires_at')),
            );
            $scopeType = $request->validated('scope_type');
            $scopeKey = $request->validated('scope_key');
            if (is_string($scopeType) && is_string($scopeKey) && $scopeType !== '' && $scopeKey !== '') {
                $assignScope->handle($created, new ScopeReference($scopeType, $scopeKey), $context->actor($request));
            } elseif ($role->code === AuthorizationBundleCatalog::CHURCH_OPERATIONS_ADMINISTRATOR_ROLE) {
                $reconcileChurchScopes->handle($target);
                $created->refresh();
                $created->load('scopeAssignments');
                $hasChurchScope = $created->scopeAssignments->contains(
                    fn ($scope): bool => $scope->scope_type === 'church',
                );
                if (! $hasChurchScope) {
                    throw new InvalidArgumentException(
                        'Church operations administrator requires a church scope. Select the church this person administers.',
                    );
                }
            }

            return $created;
        });
        $assignment->load(['role:id,public_id,code', 'user:id,public_id']);

        return ApiResponse::success($request, [
            'id' => $assignment->public_id,
            'user_id' => $assignment->user?->public_id,
            'role_id' => $assignment->role?->public_id,
            'role_code' => $assignment->role?->code,
            'assigned_at' => $assignment->assigned_at?->utc()->toIso8601String(),
            'expires_at' => $assignment->expires_at?->utc()->toIso8601String(),
        ], status: 201);
    }

    public function revokeRole(Request $request, string $user, string $roleAssignment, RevokeRoleFromUserAction $action, ProtectedAdminContext $context): JsonResponse
    {
        $context->ensureGlobal($request);
        $target = User::query()->where('public_id', $user)->firstOrFail();
        $assignment = RoleAssignment::query()
            ->with('role:id,public_id,code,name')
            ->where('public_id', $roleAssignment)
            ->where('user_id', $target->getKey())
            ->firstOrFail();
        if ($assignment->role?->code === AuthorizationBundleCatalog::SUPER_ADMINISTRATOR_ROLE) {
            $this->assertActorHoldsSuperAdministrator($context->actor($request));
        }
        $revoked = $this->execute(fn (): RoleAssignment => $action->handle(
            $context->actor($request),
            $target,
            $assignment,
        ));
        $revoked->load(['role:id,public_id,code', 'user:id,public_id']);

        return ApiResponse::success($request, [
            'id' => $revoked->public_id,
            'user_id' => $revoked->user?->public_id,
            'role_id' => $revoked->role?->public_id,
            'role_code' => $revoked->role?->code,
            'revoked_at' => $revoked->revoked_at?->utc()->toIso8601String(),
        ]);
    }

    public function assignScope(AssignScopeToRoleAssignmentRequest $request, string $roleAssignment, AssignScopeToRoleAssignmentAction $action, ProtectedAdminContext $context): JsonResponse
    {
        $context->ensureGlobal($request);
        $target = RoleAssignment::query()->where('public_id', $roleAssignment)->firstOrFail();
        $scopeAssignment = $this->execute(fn (): ScopeAssignment => $action->handle(
            $target,
            new ScopeReference((string) $request->validated('scope_type'), (string) $request->validated('scope_key')),
            $context->actor($request),
        ));

        return ApiResponse::success($request, [
            'id' => $scopeAssignment->public_id,
            'role_assignment_id' => $target->public_id,
            'scope_type' => $scopeAssignment->scope_type,
            'scope_key' => $scopeAssignment->scope_key,
        ], status: 201);
    }

    public function grantPermission(GrantPermissionToRoleRequest $request, string $role, GrantPermissionToRoleAction $action, ProtectedAdminContext $context, ListUserCapabilitiesQuery $capabilities): JsonResponse
    {
        $context->ensureGlobal($request);
        $target = Role::query()->where('public_id', $role)->firstOrFail();
        $permission = Permission::query()->where('public_id', $request->validated('permission_id'))->firstOrFail();
        $held = $capabilities->handle($context->actor($request))['permissions'];
        if (! in_array($permission->code, $held, true)) {
            throw new AccessDeniedHttpException('Cannot grant a permission you do not hold.');
        }
        $grant = $this->execute(fn (): RolePermission => $action->handle($target, $permission, $context->actor($request)));
        $grant->load(['role:id,public_id,code', 'permission:id,public_id,code']);

        return ApiResponse::success($request, [
            'id' => $grant->public_id,
            'role_id' => $grant->role?->public_id,
            'permission_id' => $grant->permission?->public_id,
            'permission_code' => $grant->permission?->code,
        ], status: 201);
    }

    private function assertActorHoldsSuperAdministrator(User $actor): void
    {
        $holds = $actor->roleAssignments()
            ->active()
            ->whereHas('role', fn ($query) => $query->where('code', AuthorizationBundleCatalog::SUPER_ADMINISTRATOR_ROLE))
            ->exists();
        if (! $holds) {
            throw new AccessDeniedHttpException('Only a super-administrator may assign that role.');
        }
    }
}
