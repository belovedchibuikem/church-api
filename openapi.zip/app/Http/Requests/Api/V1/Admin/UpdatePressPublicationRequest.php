<?php

namespace App\Http\Requests\Api\V1\Admin;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdatePressPublicationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return PressPublicationPayloadRules::rules(creating: false);
    }

    /** @return array<string, string> */
    public function attributes(): array
    {
        return PressPublicationPayloadRules::attributes();
    }

    /** @return array<string, string> */
    public function messages(): array
    {
        return PressPublicationPayloadRules::messages();
    }
}
